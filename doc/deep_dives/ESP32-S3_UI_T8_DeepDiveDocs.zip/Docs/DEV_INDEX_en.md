# Deep-Dive Documentation (Developer)

These pages target developers who want to **understand, fork, or extend** the project.
They complement the management-focused README and intentionally go deeper into architecture, workflows, states, and screen-specific behavior.

> Note: Primary language is German. Source code, comments, and technical artifacts remain English.

## Contents

1. [Architecture Overview](Dev/01_architektur_en.md)
2. [Workflow: UI ↔ oven ↔ HostComm](Dev/02_workflows_en.md)
3. [States and Flags (RUNNING, WAITING, POST, Link/Alive)](Dev/03_zustaende_en.md)
4. [screen_main – Runtime View](Dev/04_screen_main_en.md)
5. [screen_config – Configuration](Dev/05_screen_config_en.md)
6. [screen_dbg_hw – Hardware Debug Screen (Safety)](Dev/06_screen_dbg_hw_en.md)

## Reference: Development Phases (T1–T8)

- T1–T2: Foundations (display/touch, LVGL setup, first architecture draft)
- T3–T8: Implementation iterations (UI, workflows, communication, debug screen, navigation)

Phase summaries are available under `Docs/`:

- `Docs/ESP32-S3_UI_T3_Zusammenfassung.md`
- `Docs/ESP32-S3_UI_T4_Zusammenfassung.md`
- `Docs/ESP32-S3_UI_T5_Zusammenfassung.md`
- `Docs/ESP32-S3_UI_T6_Zusammenfassung.md`
- `Docs/ESP32-S3_UI_T7_Zusammenfassung.md`
- `Docs/ESP32-S3_UI_T8_Zusammenfassung.md`

## Mermaid Notes

Mermaid can be sensitive to special characters. Diagram labels are therefore often wrapped in **quotes**.
