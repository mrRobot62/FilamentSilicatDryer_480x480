#include <Arduino.h>
#include <lvgl.h>
// #include <esp_heap_caps.h>

// #include "display/display_hsd040bpn1.h"
// #include "touch.h"

#include "ui/ui.h"
#include "ui/ui_events.h"

// LVGL Display-Handle und Zeichnen-Puffer
// static lv_display_t *lv_disp = nullptr;
// static lv_draw_buf_t lv_draw_buf;
// static lv_color_t *lv_buf1 = nullptr;

// // LVGL Input-Device für Touch
// static lv_indev_t *indev_touch = nullptr;

// // Flush-Callback: LVGL -> GFX
// static void my_disp_flush(lv_display_t *disp, const lv_area_t *area, uint8_t *px_map)
// {
//     uint32_t w = (area->x2 - area->x1 + 1);
//     uint32_t h = (area->y2 - area->y1 + 1);

//     // LV_COLOR_DEPTH = 16 -> px_map zeigt auf RGB565
//     uint16_t *src = (uint16_t *)px_map;

//     gfx->draw16bitRGBBitmap(area->x1, area->y1, src, w, h);

//     lv_display_flush_ready(disp);
// }

// Touch-Callback für LVGL 9
// static void my_touch_read(lv_indev_t *indev, lv_indev_data_t *data)
// {
//     LV_UNUSED(indev);

//     bool touched = false;

//     if (touch_has_signal())
//     {
//         touched = touch_touched();
//     }

//     if (touched)
//     {
//         data->state = LV_INDEV_STATE_PRESSED;
//         data->point.x = touch_last_x;
//         data->point.y = touch_last_y;
//     }
//     else
//     {
//         data->state = LV_INDEV_STATE_RELEASED;
//     }
// }

void setup()
{
    Serial.begin(115200);
    delay(4000); // damit du sicher die Setup-Logs siehst

    Serial.println();
    Serial.println(F("=== ESP32-S3 + ST7701 480x480 + LVGL 9.4.x + Touch ==="));

    // // 1) Display (GFX) initialisieren
    // if (!init_display())
    // {
    //     Serial.println(F("[MAIN] Display init FAILED, stopping."));
    //     while (true)
    //     {
    //         delay(1000);
    //     }
    // }
    // Serial.println(F("[MAIN] Display init OK"));

    // // 2) LVGL initialisieren
    // lv_init();
    // Serial.println(F("[MAIN] lv_init() OK"));

    // 3) LVGL-Draw-Puffer
    // const uint32_t buf_lines = 80;
    // const uint32_t buf_pixels = SCREEN_WIDTH * buf_lines;

    // lv_buf1 = (lv_color_t *)heap_caps_malloc(
    //     buf_pixels * sizeof(lv_color_t),
    //     MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);

    // if (!lv_buf1)
    // {
    //     Serial.println(F("[MAIN] LVGL draw buffer alloc FAILED"));
    //     while (true)
    //     {
    //         delay(1000);
    //     }
    // }
    // Serial.print(F("[MAIN] LVGL draw buffer alloc OK, pixels="));
    // Serial.println(buf_pixels);

    // lv_draw_buf_init(
    //     &lv_draw_buf,
    //     SCREEN_WIDTH,
    //     buf_lines,
    //     LV_COLOR_FORMAT_RGB565,
    //     SCREEN_WIDTH,
    //     lv_buf1,
    //     buf_pixels * sizeof(lv_color_t));

    // // 4) Display-Objekt
    // lv_disp = lv_display_create(SCREEN_WIDTH, SCREEN_HEIGHT);
    // if (!lv_disp)
    // {
    //     Serial.println(F("[MAIN] lv_display_create() FAILED"));
    //     while (true)
    //     {
    //         delay(1000);
    //     }
    // }
    // Serial.println(F("[MAIN] lv_display_create() OK"));

    // lv_display_set_flush_cb(lv_disp, my_disp_flush);
    // lv_display_set_draw_buffers(lv_disp, &lv_draw_buf, nullptr);
    // Serial.println(F("[MAIN] lv_display_set_draw_buffers() OK"));

    // // 5) Touch initialisieren
    // touch_init();
    // Serial.println(F("[MAIN] touch_init() OK"));

    // // 6) LVGL Input-Device einrichten
    // indev_touch = lv_indev_create();
    // lv_indev_set_type(indev_touch, LV_INDEV_TYPE_POINTER);
    // lv_indev_set_read_cb(indev_touch, my_touch_read);
    // Serial.println(F("[MAIN] LVGL input device (touch) created"));

    // 7) UI erzeugen
    ui_init();
    Serial.println(F("[MAIN] ui_init() OK"));
}

void loop()
{
    lv_timer_handler();
    delay(5);

    static uint32_t last_beat = 0;
    uint32_t now = millis();
    if (now - last_beat > 5000)
    {
        last_beat = now;
        Serial.println(F("[MAIN] loop() heartbeat"));
    }
}