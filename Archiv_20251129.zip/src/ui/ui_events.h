#pragma once

#include <lvgl.h>

// Event-Callback für den Button
void ui_event_ButtonTest(lv_event_t *e);