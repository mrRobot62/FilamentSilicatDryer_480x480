#include <Arduino.h>
#include "ui/ui_events.h"
#include "ui/ui.h"

void ui_event_ButtonTest(lv_event_t *e)
{
    lv_event_code_t code = lv_event_get_code(e);

    if (code == LV_EVENT_CLICKED)
    {
        Serial.println(F("[UI] ButtonTest clicked"));

        if (ui_LabelInfo)
        {
            static bool toggled = false;
            toggled = !toggled;
            lv_label_set_text(ui_LabelInfo, toggled ? "Clicked!" : "Touch me!");
        }
    }
}